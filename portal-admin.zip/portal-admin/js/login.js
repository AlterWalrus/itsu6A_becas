document.getElementById("btnIniciar").addEventListener("click", function () {
    window.location.href = "dashboard.html";
  });